<!DOCTYPE html>
<html>

<head>

<?php include ('adminlink.php'); ?>
</head>

<body>
<?php include ('adminheader.php'); ?>

<?php include ('adminfooter.php'); ?>
    
</body>
</html>