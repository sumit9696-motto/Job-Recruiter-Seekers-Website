<style>
    hr{
  
  background-color: white;
}
</style>







<!-- start footer  -->
<div class="row " >

    <div class="col-sm-12 bg-dark" style="min-height: 600px;">
    <div class="container">
      <div class="row tfooter">
        
        <div class="col-sm-3">
          <div class="row p-2 ">
            <div class="col-sm-12  text-light" style="height: 400px;">
              <img src="img/joblo.png" style="height: 80px; width:150px;">
              <br><br>
              <b>Lorem ipsum dolor sit amet, 
                consectetur adipisicing elit, 
                sed do eiusmod tempor incididunt ut labore et 
                dolore magna aliqua.</b>
                <br><br>
                <a href="#"><span class="fa fa-youtube-play text-light m-3"></span></a>
                <a href="#"><span class="fa fa-facebook text-light m-3"></span></a>
                <a href="#"><span class="fa fa-instagram text-light m-3"></span></a>
                <a href="#"><span class="fa fa-twitter text-light m-3"></span></a>
                
            
            
            
            
            </div>
          </div>
          </div>
    
          
        <div class="col-sm-3">
          <div class="row p-2 ">
            <div class="col-sm-12 text-light" style="height: 400px;">
            <h3>Category</h3>
            <hr>
            <br>
            <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b> Development</b> </a> <br> <br>
            <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b>  Business</b> </a> <br> <br>
            <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b>  Tech & IT</b> </a> <br> <br>
            <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b>  Finance</b> </a> <br> <br>
            <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b> Networking</b> </a>
    
            
            </div>
          </div>
          </div>
    
          <div class="col-sm-3">
            <div class="row p-2 ">
              <div class="col-sm-12  text-light" style="height: 400px;">
              <h3>Quick Links</h3>
              <hr>
              <br>
              <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b> Home</b> </a> <br> <br>
              <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b>  about us</b> </a> <br> <br>
              <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b> Find Jobs</b> </a> <br> <br>
              <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b>  Contact us</b> </a> <br> <br>
              <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-chevron-right"></span><b>registration</b> </a>
      
              
              </div>
            </div>
            </div>
      
            <div class="col-sm-3">
              <div class="row p-2 ">
                <div class="col-sm-12  text-light" style="height: 400px;">
                <h3>Find Us</h3>
                <hr>
                <br>
                <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-home"></span><b> st/pt/Gb pant</b> </a> <br> <br>
                <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-phone"></span><b>  +91 9455929984</b> </a> <br> <br>
                <a href="#" class="text-light" style="text-decoration: none;"> <span class="fa fa-envelope-o"></span><b> help@.gmail.com</b> </a> <br> <br>
        
                
                </div>
              </div>
              </div>
            
        
    
      </div>
    <hr>
      
      <div class="row bfooter">
        <div class="container">
          <div class="row">
            <div class="col-sm-8 mt-5">            <a href="#" class="text-light" style="text-decoration: none;"> <b> Copyright @2020 Gable. Designed by HiBootstrap</b> </a> 
            </div>
            <div class="col-sm-4 mt-5">
    
              <a href="#" class="text-light" style="text-decoration: none;"> <b> 
                Terms & Conditions - Privacy Policy</b> </a> 
            </div>
          </div>
        </div>
      </div>
    </div>
    
    </div>
    </div>
    
    
    
    
    <!-- end footer -->